#include "ft_printf.h"
int main()
{
    int x = printf("| %.1u |\n",0);
    int y = ft_printf("| %.1u  |\n",0);
    printf("%d \t %d\n",x , y);
}